# Auto geração de questões com IA

## Instalar

Dentro de `revalida-api`:

```bash
source .venv/bin/activate
pip install -r tools/requirements-ai.txt
```

## Configurar chave

```bash
export OPENAI_API_KEY="sua_chave_aqui"
```

Opcional:

```bash
export OPENAI_MODEL="gpt-5.4-mini"
```

## Rodar teste com 1 prompt

```bash
python tools/auto_generate_questions.py --limit 1
```

## Rodar todos

```bash
python tools/auto_generate_questions.py
```

Saída:

```txt
storage/imports/questions.json
storage/imports/questions.rejected.json
```

Importar no Laravel:

```bash
php artisan questions:import-json
```
