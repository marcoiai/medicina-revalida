import argparse
import json
import os
import re
import time
from pathlib import Path

from openai import OpenAI
from jsonschema import validate, ValidationError

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_BATCH_DIR = ROOT / "storage" / "imports" / "json" / "ai_batches"
DEFAULT_OUTPUT = ROOT / "storage" / "imports" / "questions.json"

QUESTION_SCHEMA = {
    "type": "object",
    "required": ["area", "tema", "dificuldade", "enunciado", "alternativas", "gabarito", "comentario"],
    "properties": {
        "area": {"type": "string"},
        "tema": {"type": "string"},
        "dificuldade": {"type": "string"},
        "enunciado": {"type": "string"},
        "alternativas": {
            "type": "object",
            "required": ["A", "B", "C", "D", "E"],
            "properties": {
                "A": {"type": "string"},
                "B": {"type": "string"},
                "C": {"type": "string"},
                "D": {"type": "string"},
                "E": {"type": "string"},
            },
        },
        "gabarito": {"type": "string", "enum": ["A", "B", "C", "D", "E"]},
        "comentario": {"type": "string"},
        "origin": {"type": "string"},
        "status": {"type": "string"},
        "reference": {"type": "string"},
        "tags": {},
    },
}

def extract_json_array(text: str):
    """
    Handles model responses that may include Markdown fences.
    """
    text = text.strip()

    fence = re.search(r"```(?:json)?\s*(.*?)```", text, flags=re.DOTALL | re.IGNORECASE)
    if fence:
        text = fence.group(1).strip()

    start = text.find("[")
    end = text.rfind("]")
    if start == -1 or end == -1 or end <= start:
        raise ValueError("No JSON array found in model output.")

    return json.loads(text[start:end + 1])

def normalize_question(q: dict) -> dict:
    q.setdefault("origin", "official_based")
    q.setdefault("status", "draft")
    q.setdefault("reference", "")
    q.setdefault("tags", [])

    # Normalize answer letter.
    q["gabarito"] = str(q.get("gabarito", "")).strip().upper()

    # Trim all option labels.
    if "alternativas" in q and isinstance(q["alternativas"], dict):
        q["alternativas"] = {k.upper(): str(v).strip() for k, v in q["alternativas"].items()}

    return q

def validate_question(q: dict):
    validate(instance=q, schema=QUESTION_SCHEMA)

    if len(q["enunciado"].strip()) < 30:
        raise ValidationError("Enunciado muito curto.")

    if len(q["comentario"].strip()) < 30:
        raise ValidationError("Comentário muito curto.")

    for letter in ["A", "B", "C", "D", "E"]:
        if len(q["alternativas"][letter].strip()) < 2:
            raise ValidationError(f"Alternativa {letter} vazia ou curta demais.")

def call_model(client: OpenAI, model: str, prompt: str, retries: int = 3):
    system = (
        "Você cria questões médicas originais, em português do Brasil, para Revalida e residência. "
        "Responda SOMENTE com JSON válido. Não use Markdown. Não copie enunciados oficiais literalmente."
    )

    for attempt in range(1, retries + 1):
        try:
            response = client.responses.create(
                model=model,
                input=[
                    {"role": "system", "content": system},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.4,
            )
            return response.output_text
        except Exception as e:
            if attempt == retries:
                raise
            wait = 2 * attempt
            print(f"  erro API: {e}; retry em {wait}s")
            time.sleep(wait)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--batch-dir", default=str(DEFAULT_BATCH_DIR))
    parser.add_argument("--output", default=str(DEFAULT_OUTPUT))
    parser.add_argument("--model", default=os.getenv("OPENAI_MODEL", "gpt-5.4-mini"))
    parser.add_argument("--limit", type=int, default=0, help="Limit number of prompt files for testing.")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise SystemExit("Missing OPENAI_API_KEY. Export it before running.")

    batch_dir = Path(args.batch_dir)
    output = Path(args.output)
    prompts = sorted(batch_dir.glob("*.prompt.txt"))

    if args.limit:
        prompts = prompts[:args.limit]

    if not prompts:
        raise SystemExit(f"No .prompt.txt files found in {batch_dir}")

    client = OpenAI(api_key=api_key)
    all_questions = []
    rejected = []

    for idx, prompt_path in enumerate(prompts, 1):
        print(f"[{idx}/{len(prompts)}] {prompt_path.name}")
        prompt = prompt_path.read_text(encoding="utf-8")

        if args.dry_run:
            print(prompt[:1000])
            continue

        raw = call_model(client, args.model, prompt)

        try:
            items = extract_json_array(raw)
        except Exception as e:
            rejected.append({"file": prompt_path.name, "error": f"JSON parse: {e}", "raw": raw[:3000]})
            print(f"  rejeitado: JSON inválido")
            continue

        accepted_count = 0
        for q in items:
            try:
                q = normalize_question(q)
                validate_question(q)
                all_questions.append(q)
                accepted_count += 1
            except Exception as e:
                rejected.append({"file": prompt_path.name, "error": str(e), "question": q})

        print(f"  aceitas: {accepted_count} / {len(items)}")

    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(all_questions, ensure_ascii=False, indent=2), encoding="utf-8")

    rejected_path = output.with_name("questions.rejected.json")
    rejected_path.write_text(json.dumps(rejected, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"\nOK: {len(all_questions)} questões salvas em {output}")
    print(f"Rejeitadas/erros: {len(rejected)} em {rejected_path}")
    print("\nImporte no Laravel com:")
    print("php artisan questions:import-json")

if __name__ == "__main__":
    main()
